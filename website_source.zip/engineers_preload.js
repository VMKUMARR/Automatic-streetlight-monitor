var faultyLightsClass = "assigned-for-maintainance";
