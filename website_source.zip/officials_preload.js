var faultyLightsClass = "not-working";
